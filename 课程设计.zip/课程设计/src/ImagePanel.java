import javax.swing.*;
import java.awt.*;

public class ImagePanel extends JPanel {
    private Image image;

    public ImagePanel(String imagePath) {
        // 加载图片
        image = new ImageIcon(imagePath).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        // 绘制图片
        if (image != null) {
            g.drawImage(image, 0, 0, null); // 从左上角开始绘制图片
        }
    }

    public static void main(String[] args) {
        // 创建窗体
        JFrame frame = new JFrame("加载图片");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1600, 1000);

        // 创建一个面板，并加载图片
        ImagePanel panel = new ImagePanel("D:\\课程设计\\src\\CourseDesign\\qq.jpg");
        frame.add(panel);

        // 显示窗体
        frame.setVisible(true);
    }
}
