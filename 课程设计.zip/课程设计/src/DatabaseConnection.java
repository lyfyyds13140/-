import java.sql.*;

public class DatabaseConnection {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/mysql";
        String username = "root";
        String password = "root";

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            System.out.println("成功连接到数据库!");

            // 执行查询
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM sort";  // 替换为实际的表名
            ResultSet resultSet = statement.executeQuery(query);

           /* while (resultSet.next()) {
                String columnValue = resultSet.getString("column_name"); // 替换为实际列名
                System.out.println(columnValue);
            }*/

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
