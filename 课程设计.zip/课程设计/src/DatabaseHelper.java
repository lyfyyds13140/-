import java.sql.*;

public class DatabaseHelper {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/game_scores"; // MySQL数据库的连接URL
    private static final String USER = "root";  // MySQL用户名
    private static final String PASSWORD = "root";  // MySQL密码

    // 创建连接
    public static Connection connect() {
        try {
            return DriverManager.getConnection(DB_URL, USER, PASSWORD);
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 插入分数
    public static void insertScore(String playerName, int score) {
        String insertSQL = "INSERT INTO scores (player_name, score) VALUES (?, ?)";

        try (Connection conn = connect(); PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {
            pstmt.setString(1, playerName);
            pstmt.setInt(2, score);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // 查询分数
    public static void fetchScores() {
        String selectSQL = "SELECT * FROM scores ORDER BY score DESC LIMIT 10";  // 查询前10名
        try (Connection conn = connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(selectSQL)) {
            while (rs.next()) {
                int id = rs.getInt("id");
                String playerName = rs.getString("player_name");
                int score = rs.getInt("score");
                String date = rs.getString("date");
                System.out.println(id + " | " + playerName + " | " + score + " | " + date);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
