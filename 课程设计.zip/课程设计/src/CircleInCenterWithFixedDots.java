import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;
import java.io.IOException;

//import javazoom.jl.decoder.Bitstream;

//import javazoom.jl.decoder.Player;

import java.io.File;


public class CircleInCenterWithFixedDots {
    private static int RADIUS = 20;  // 圆的半径
    private static  int SPEED = 4;    // 圆移动的速度
    private static final int WINDOW_WIDTH = 1600;  // 窗口宽度
    private static final int WINDOW_HEIGHT = 1000; // 窗口高度
    private static ArrayList<AvatarPlayer> avatarPlayer=new ArrayList<>();
    private static ArrayList<Point> dots = new ArrayList<>();
    private static ArrayList<Point> playdots = new ArrayList<>();  // 存储小圆点的位置
    private static ArrayList<AIPlayer> aiPlayers = new ArrayList<>(); // 存储多个AI玩家

    private static int circleX = WINDOW_WIDTH / 2; // 圆形的初始X位置
    private static int circleY = WINDOW_HEIGHT / 2; // 圆形的初始Y位置
    private static int dotsx = 0;
    private static int dotsy = 0;
    private static double fg=0;
    private static int score =0;
    private static Random random = new Random();

    public  static void showScores2() {
        DatabaseHelper.fetchScores();
    }

    public  static void saveScoreToDatabase2() {
        String playerName = "刘亚";  // 玩家名字，可以根据实际情况进行修改
        int Score =score;// 获取当前分数
        DatabaseHelper.insertScore(playerName, Score);
    }
    public static void checkCollision() {


        ArrayList<Point> eatendots1 = new ArrayList<>();
        ArrayList<Point> eatendots2 = new ArrayList<>();
        ArrayList<AIPlayer> eatenAIPlayers = new ArrayList<>();
        ArrayList<AvatarPlayer> eatenavatarPlayer=new ArrayList<>();


        for (int i = 0; i < avatarPlayer.size() - 1; i++) {
            AvatarPlayer avatarplayer1 = avatarPlayer.get(i); // 获取第 i 个元素
            for (int j = i+1; j < avatarPlayer.size(); j++) {
                AvatarPlayer avatarplayer2 = avatarPlayer.get(j); // 获取第 j 个元素
                if (Math.hypot(avatarplayer1.circleX -  avatarplayer2.circleX, avatarplayer1.circleY -avatarplayer2.circleY) < (avatarplayer1.RADIUS +  avatarplayer2.RADIUS)/2)
                {eatenavatarPlayer.add(avatarplayer2);
                    avatarplayer1.RADIUS=(int)Math.sqrt( avatarplayer1.RADIUS* avatarplayer1.RADIUS+ avatarplayer2.RADIUS* avatarplayer2.RADIUS);
                }
            } avatarPlayer.removeAll(eatenavatarPlayer);
        }


        for (AvatarPlayer  avatarplayer: avatarPlayer) {
        double x = 20,y=0,i=1;
        for (Point dot : dots) {
            if (Math.hypot(avatarplayer.circleX - dot.x,avatarplayer.circleY - dot.y) < avatarplayer.RADIUS) {
                eatendots1.add(dot);
              if(avatarplayer.RADIUS<=250) {
                  y = x;
                  x += 20 / x;  // x递增，每次增加值变小
                  if (x - y >= i) {
                      avatarplayer.RADIUS += 1; // 玩家变大
                      x = avatarplayer.RADIUS;
                      i = Math.log(avatarplayer.RADIUS - 17);
                      avatarplayer.SPEED=4- avatarplayer.RADIUS/100;
                      if( avatarplayer.RADIUS>=300) { avatarplayer.SPEED=1;}
                  }
              }
            }
        }
        for (AIPlayer aiPlayer : aiPlayers) {
            if (Math.hypot(avatarplayer.circleX - aiPlayer.x, avatarplayer.circleY - aiPlayer.y) < (avatarplayer.RADIUS + aiPlayer.radius)/2) {
                // 玩家比人机大，吃掉人机并变大
                if (avatarplayer.RADIUS > aiPlayer.radius) {
                    eatenAIPlayers.add(aiPlayer);
                    avatarplayer.RADIUS = (int)Math.sqrt(aiPlayer.radius*aiPlayer.radius+ avatarplayer.RADIUS* avatarplayer.RADIUS); // 玩家变大
               avatarplayer.SPEED=4- avatarplayer.RADIUS/100;
                    if( avatarplayer.RADIUS>=300) { avatarplayer.SPEED=1;}
                }
                if (avatarplayer.RADIUS < aiPlayer.radius) {eatenavatarPlayer.add(avatarplayer);
                    aiPlayer.radius = (int)Math.sqrt(aiPlayer.radius*aiPlayer.radius+ avatarplayer.RADIUS* avatarplayer.RADIUS);}
            }
        }



        for (Point playdot : playdots){
            if (Math.hypot(avatarplayer.circleX - playdot.x, avatarplayer.circleY - playdot.y) < avatarplayer.RADIUS) {
                eatendots2.add(playdot);
                avatarplayer.RADIUS += 2; // 玩家变大
                avatarplayer.SPEED=4- avatarplayer.RADIUS/100;
                if( avatarplayer.RADIUS>=300) { avatarplayer.SPEED=1;}
            }
        }aiPlayers.removeAll(eatenAIPlayers);  // 移除被吃掉的人机
            playdots.removeAll(eatendots2);
            dots.removeAll(eatendots1);
            avatarPlayer.removeAll(eatenavatarPlayer);
    }
    }
    static class AIPlayerThread implements Runnable {
        private final AIPlayer aiPlayer;

        public AIPlayerThread(AIPlayer aiPlayer) {
            this.aiPlayer = aiPlayer;
        }

        @Override
        public void run() {
            while (true) {
               aiMove();
                try {
                    Thread.sleep(10);  // 人机每50ms更新一次位置
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }}

        public static void aiMove() {
        for (AIPlayer aiPlayer : aiPlayers) {
            // 人机随机选择一个方向进行移动
            double x = 20,y=0,i=1;
            Point nearestDot = null;
            double minDistance = Double.MAX_VALUE;
            for (Point dot : dots) {
                double dist = Math.hypot(aiPlayer.x - dot.x, aiPlayer.y - dot.y);
                if (dist < minDistance) {
                    minDistance = dist;
                    nearestDot = dot;
                }
            }

            // 如果找到最近的小圆点，朝它移动
            if (nearestDot != null) {
                int deltaX = nearestDot.x - aiPlayer.x;
                int deltaY = nearestDot.y -aiPlayer.y;

                double angle = Math.atan2(deltaY, deltaX);
                aiPlayer.x += (int)(SPEED * Math.cos(angle));
                aiPlayer.y += (int)(SPEED * Math.sin(angle));
            }


            // 确保人机不会移动出屏幕范围
            aiPlayer.x = Math.max(0, Math.min(aiPlayer.x, WINDOW_WIDTH));
            aiPlayer.y = Math.max(0, Math.min(aiPlayer.y, WINDOW_HEIGHT));

            // 人机吃小圆点变大
            ArrayList<Point> eatendots = new ArrayList<>();
            for (Point dot : dots) {
                if (Math.hypot(aiPlayer.x - dot.x, aiPlayer.y - dot.y) < aiPlayer.radius) {
                    eatendots.add(dot);
                    y = x;
                    x += 20 / x;  // x递增，每次增加值变小
                    if (x - y >= i) {
                        aiPlayer.radius += 1; // 玩家变大
                        x =  aiPlayer.radius;
                        i = Math.log( aiPlayer.radius - 17);
                    }


                }
            }
            dots.removeAll(eatendots);  // 移除已吃掉的小圆点
        }
    }

    // 创建人机对象
    public static void createAIPlayers(int count) {
        for (int i = 0; i < count; i++) {
            int x = random.nextInt(WINDOW_WIDTH);
            int y = random.nextInt(WINDOW_HEIGHT);
            int radius = 20; // 给每个人机一个半径
            AIPlayer aiPlayer = new AIPlayer(x, y, radius);
            aiPlayers.add(aiPlayer);
            // 启动独立线程来控制人机行为
            Thread aiThread = new Thread(new AIPlayerThread(aiPlayer));
            aiThread.start(); // 启动线程
        }
    }
    public static void main(String[] args) {
        // 随机生成小圆点
        Random random = new Random();
        for (int i = 0; i < 5000; i++) {
            int x = random.nextInt(8000);
            int y = random.nextInt(8000);
            dots.add(new Point(x, y));  // 每个小圆点的位置
        }
        createAIPlayers(10);
        avatarPlayer.add(new AvatarPlayer(circleX, circleY, RADIUS, SPEED));
        // 创建窗体
        JFrame frame = new JFrame("圆形始终在屏幕中间，背景上的小圆点凸显圆的移动");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        // 创建面板，重写 paintComponent 方法

        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);

                // 计算圆形朝向鼠标的方向
                Point mousePosition = getMousePosition();
                if (mousePosition != null) {
                    int mouseX = mousePosition.x;
                    int mouseY = mousePosition.y;

                    // 计算圆心到鼠标位置的方向向量
                    int deltaX = mouseX - WINDOW_WIDTH / 2;
                    int deltaY = mouseY - WINDOW_HEIGHT / 2;

                    // 计算朝向鼠标的角度
                    double angle = Math.atan2(deltaY, deltaX);
                    fg = angle;
                    // 根据角度更新圆的位置
                    int count = 0, circlex = 800, circley = 600;
                    for (AvatarPlayer avatarplayer : avatarPlayer) {

                        int deltax = mouseX - (800 + avatarplayer.circleX - circlex);
                        int deltay = mouseY - (800 + avatarplayer.circleY - circley);

                        avatarplayer.circleX += (int) (avatarplayer.SPEED * Math.cos(angle));
                        avatarplayer.circleY += (int) (avatarplayer.SPEED * Math.sin(angle));
                        if (count == 0) {
                            count = 1;
                            circlex = avatarplayer.circleX;
                            circley = avatarplayer.circleY;
                            SPEED = avatarplayer.SPEED;
                            RADIUS = avatarplayer.RADIUS;
                        }
                        // 绘制圆形
                        g.setColor(Color.BLUE);
                        g.fillOval(WINDOW_WIDTH / 2 + avatarplayer.circleX - circlex - avatarplayer.RADIUS, WINDOW_HEIGHT / 2 + avatarplayer.circleY - circley - avatarplayer.RADIUS, avatarplayer.RADIUS * 2, avatarplayer.RADIUS * 2);
                    }

                    dotsy -= (int) (SPEED * Math.sin(angle));
                    dotsx -= (int) (SPEED * Math.cos(angle));


                }


                g.setColor(Color.RED);
                checkCollision();
// 绘制固定的小圆点
                for (Point dot : dots) {
                    g.fillOval(dot.x + dotsx, dot.y + dotsy, 5, 5);  // 小圆点半径为 5
                }


                // 绘制玩家生成的小圆点
                g.setColor(Color.GREEN);
                for (Point playdot : playdots) {
                    g.fillOval(playdot.x + dotsx, playdot.y + dotsy, 20, 20);  // 小圆点半径为 20
                }
                g.setColor(Color.GREEN);
                // 绘制人机的圆形
                for (AIPlayer aiPlayer : aiPlayers) {
                    g.fillOval(aiPlayer.x - aiPlayer.radius + dotsx, aiPlayer.y - aiPlayer.radius + dotsy, aiPlayer.radius * 2, aiPlayer.radius * 2);
                }
            }
        };

        // 设置 KeyListener 监听键盘按键
        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                if (key == KeyEvent.VK_A) {
                    for (AvatarPlayer avatarplayer : avatarPlayer) {
                        if (avatarplayer.RADIUS > 40) {
                            int x = avatarplayer.circleX + 2 * (int) (avatarplayer.SPEED * Math.cos(fg) + avatarplayer.RADIUS * Math.cos(fg));
                            int y = avatarplayer.circleY + 2 * (int) (avatarplayer.SPEED * Math.sin(fg) + avatarplayer.RADIUS * Math.sin(fg));
                            playdots.add(new Point(x, y));
                            avatarplayer.RADIUS -= 2; // 玩家变小
                            avatarplayer.SPEED = 4 - avatarplayer.RADIUS / 100;
                            if (avatarplayer.RADIUS >= 300) {
                                avatarplayer.SPEED = 1;
                            }

                        }
                    }
                }
                if (key == KeyEvent.VK_D) {
                    ArrayList<AvatarPlayer> newPlayers = new ArrayList<>();
                    for (AvatarPlayer avatarplayer : avatarPlayer) {
                        if (avatarPlayer.size() < 16) {
                            if (avatarplayer.RADIUS >= 50) {
                                int x = avatarplayer.circleX + 2 * (int) (avatarplayer.SPEED * Math.cos(fg) + avatarplayer.RADIUS * Math.cos(fg));
                                int y = avatarplayer.circleY + 2 * (int) (avatarplayer.SPEED * Math.sin(fg) + avatarplayer.RADIUS * Math.sin(fg));
                                int r = (int) Math.sqrt(avatarplayer.RADIUS * avatarplayer.RADIUS / 2);
                                int v = 4 - r / 50;
                                newPlayers.add(new AvatarPlayer(x, y, r, v));  // 临时添加新玩家
                                avatarplayer.RADIUS = (int) Math.sqrt(avatarplayer.RADIUS * avatarplayer.RADIUS / 2); // 修改当前玩家的半径
                                avatarplayer.SPEED = 4 - avatarplayer.RADIUS / 100;
                                if (avatarplayer.RADIUS >= 300) {
                                    avatarplayer.SPEED = 1;
                                }
                            }
                        }
                    }

// 循环结束后，批量将新玩家添加到原集合
                    avatarPlayer.addAll(newPlayers);
                }
                if (key == KeyEvent.VK_T) {
                    for (AvatarPlayer avatarplayer : avatarPlayer) {
                        score += avatarplayer.RADIUS * avatarplayer.RADIUS;

                    }

                    saveScoreToDatabase2();
                    System.exit(0);
                }


            }
        });

        // 设置面板可获取焦点
        panel.setFocusable(true);
        panel.requestFocusInWindow();

        // 设置窗体内容并显示
        frame.add(panel);
        JButton runButton = new JButton("单机模式");
        JButton runButton2 = new JButton("点击查询排名");
        JButton runButton3=new JButton("球球大作战");
        JButton runButton4=new JButton("嘻嘻");
        JButton playButton = new JButton("播放音乐");

        // 添加按钮点击事件
       /* playButton.addActionListener(e -> {
            // 音乐文件路径
            String musicFile = "路径/到/球球大作战背景音效.mp3"; // 替换为你的 MP3 文件路径

            try {
                // 创建播放器
                File file = new File(musicFile);
                if (file.exists()) {
                    Player player = new Player(file);
                    // 播放音乐
                    player.play();
                } else {
                    System.out.println("音乐文件未找到！");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });*/
        ImagePanel qq = new ImagePanel("D:\\课程设计\\src\\CourseDesign\\qq.jpg");
        frame.add(qq);
        //frame.setVisible(true);
        panel.add(playButton);
        panel.add(runButton);
        panel.add(runButton2);
        panel.add(runButton3);
        panel.add(runButton4);
        // 添加到窗体
        frame.add(panel);
        frame.setVisible(true);
        Timer shrinkTimer = new Timer(500, e -> {
            // 每过0.5秒，RADIUS缩小0.01
            for (AvatarPlayer avatarplayer : avatarPlayer) {
                if (avatarplayer.RADIUS > 20) {  // 防止 RADIUS 小于 20
                    avatarplayer.RADIUS = (int) Math.round(avatarplayer.RADIUS * 0.99);
                }
            }

        });
        // 启动定时器，定时刷新界面

        Timer shrinkTimer2 = new Timer(10, e -> {
            for (int i = 0; i < 10; i++) {
                int x = random.nextInt(8000);
                int y = random.nextInt(8000);
                dots.add(new Point(x, y));  // 每个小圆点的位置
            }

        });
        // 创建定时器，每 16 毫秒刷新一次画面
        Timer timer = new Timer(16, e -> {
            panel.repaint();

            aiMove();  // 更新人机位置
        });
        runButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 点击按钮时执行另一个程序
                panel.requestFocusInWindow();
                new TopScoresFrame().setVisible(true);}});

        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frame.repaint(); panel.requestFocusInWindow();
                if (!timer.isRunning()) {  // 判断定时器是否已经在运行
                    timer.start();
                }
                if (!shrinkTimer.isRunning()) {
                    shrinkTimer.start();
                }
                if (!shrinkTimer2.isRunning()) {
                    shrinkTimer2.start();
                }
            }
        }); runButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 点击按钮时执行另一个程序
              try{  String command = "C:\\Users\\33549\\Desktop\\课程设计\\程序\\大衍筮.exe";

                // 创建 ProcessBuilder 实例
                ProcessBuilder processBuilder = new ProcessBuilder(command);

                // 启动外部程序
                Process process = processBuilder.start();

                // 等待程序执行完毕
                //process.waitFor();
                System.out.println("程序已执行完毕");
            }catch (IOException a) {
                  a.printStackTrace();
                  JOptionPane.showMessageDialog(null, "启动另一个程序失败：" + a.getMessage());
              }}
        });
        playButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 点击按钮时执行另一个程序
                try{  String command = "C:\\Users\\33549\\Desktop\\音乐.bat";

                    // 创建 ProcessBuilder 实例
                    ProcessBuilder processBuilder = new ProcessBuilder(command);

                    // 启动外部程序
                    Process process = processBuilder.start();

                    // 等待程序执行完毕
                    //process.waitFor();
                    System.out.println("程序已执行完毕");
                }catch (IOException a) {
                    a.printStackTrace();
                    JOptionPane.showMessageDialog(null, "启动另一个程序失败：" + a.getMessage());
                }}
        });
    }


        // AI玩家类
    static class AvatarPlayer {
        int circleX,circleY, RADIUS,SPEED;

        public AvatarPlayer(int circleX, int circleY, int RADIUS,int SPEED) {
            this.circleX = circleX;
            this.circleY = circleY;
            this.RADIUS =RADIUS;
            this.SPEED=SPEED;
        }
    }
    static class AIPlayer {
        int x, y, radius;

        public AIPlayer(int x, int y, int radius) {
            this.x = x;
            this.y = y;
            this.radius = radius;
        }
    }
}
