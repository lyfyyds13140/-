import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TopScoresFrame extends JFrame {
    private JTable scoreTable;
    private JScrollPane scrollPane;

    public TopScoresFrame() {
        setTitle("前 10 名分数");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // 创建表格显示分数
        String[] columns = {"排名", "玩家名", "分数"};
        Object[][] data = fetchTopScores();

        scoreTable = new JTable(data, columns);
        scrollPane = new JScrollPane(scoreTable);
        add(scrollPane, BorderLayout.CENTER);
    }

    private Object[][] fetchTopScores() {
        // 获取前10名分数
        List<Score> topScores = new ArrayList<>();
        String url = "jdbc:mysql://localhost:3306/game_scores?useSSL=false&allowPublicKeyRetrieval=true";
        String user = "root";
        String password = "root";

        String query = "SELECT player_name, score FROM scores ORDER BY score DESC LIMIT 10";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                String playerName = rs.getString("player_name");
                int score = rs.getInt("score");
                topScores.add(new Score(playerName, score));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // 转换为二维数组
        Object[][] data = new Object[topScores.size()][3];
        for (int i = 0; i < topScores.size(); i++) {
            data[i][0] = i + 1;  // 排名
            data[i][1] = topScores.get(i).getPlayerName();
            data[i][2] = topScores.get(i).getScore();
        }

        return data;
    }

    // Score 类，用于存储每个玩家的名字和分数
    static class Score {
        private String playerName;
        private int score;

        public Score(String playerName, int score) {
            this.playerName = playerName;
            this.score = score;
        }

        public String getPlayerName() {
            return playerName;
        }

        public int getScore() {
            return score;
        }
    }
}
