import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;
import java.util.*;

public class GameClient {

    private static final int SERVER_PORT = 12345;
    private static Socket socket;
    private static DataInputStream input;
    private static DataOutputStream output;
    private static AvatarPlayer player;
    private static boolean isRunning = true;
    private static final int WINDOW_WIDTH = 1600;
    private static final int WINDOW_HEIGHT = 1000;
    private static ArrayList<AvatarPlayer> avatarPlayers = new ArrayList<>();
    private static ArrayList<Point> dots = new ArrayList<>();
    private static ArrayList<Point> playdots = new ArrayList<>();
    private static ArrayList<AIPlayer> aiPlayers = new ArrayList<>();
    private static Random random = new Random();

    public static void main(String[] args) {
        try {
            // 连接服务器
            socket = new Socket("lyfyyds.hopto.org", SERVER_PORT);
            input = new DataInputStream(socket.getInputStream());
            output = new DataOutputStream(socket.getOutputStream());

            // 创建一个玩家，初始位置在(100, 100)，半径为20，速度为4
            player = new AvatarPlayer(100, 100, 20, 4);

            // 启动接收服务器消息的线程
            new Thread(new ServerListener()).start();

            // 创建游戏界面和面板
            createGameWindow();

            // 启动游戏主循环
            gameLoop();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void createGameWindow() {
        JFrame frame = new JFrame("Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        // 创建面板，重写 paintComponent 方法
        JPanel panel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                renderGame(g);
            }
        };

        panel.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
        });

        panel.setFocusable(true);
        panel.requestFocusInWindow();

        frame.add(panel);
        frame.setVisible(true);

        // 定时器每 16 毫秒刷新一次画面
        // 替换掉原本的 javax.swing.Timer 引用
        javax.swing.Timer timer = new javax.swing.Timer(16, e -> panel.repaint());
        timer.start();

    }

    private static void renderGame(Graphics g) {
        // 绘制玩家、AI 和小圆点
        for (AvatarPlayer avatar : avatarPlayers) {
            g.setColor(Color.BLUE);
            g.fillOval(avatar.x - avatar.radius, avatar.y - avatar.radius, avatar.radius * 2, avatar.radius * 2);
        }

        // 绘制小圆点
        g.setColor(Color.RED);
        for (Point dot : dots) {
            g.fillOval(dot.x, dot.y, 5, 5);
        }

        // 绘制玩家生成的小圆点
        g.setColor(Color.GREEN);
        for (Point playdot : playdots) {
            g.fillOval(playdot.x, playdot.y, 20, 20);
        }

        // 绘制AI玩家的圆形
        for (AIPlayer ai : aiPlayers) {
            g.fillOval(ai.x - ai.radius, ai.y - ai.radius, ai.radius * 2, ai.radius * 2);
        }
    }

    private static void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_A) {
            for (AvatarPlayer avatar : avatarPlayers) {
                if (avatar.radius > 40) {
                    avatar.radius -= 2;  // 玩家变小
                }
            }
        } else if (key == KeyEvent.VK_D) {
            ArrayList<AvatarPlayer> newPlayers = new ArrayList<>();
            for (AvatarPlayer avatar : avatarPlayers) {
                if (avatar.radius >= 50) {
                    newPlayers.add(new AvatarPlayer(avatar.x + 10, avatar.y + 10, avatar.radius / 2, avatar.speed));
                    avatar.radius = avatar.radius / 2;
                }
            }
            avatarPlayers.addAll(newPlayers);
        }
    }

    private static void gameLoop() {
        while (isRunning) {
            // 更新玩家、AI 等状态

            updateGame();
            sendMessage(player.x + "," + player.y);
        }

        // 关闭连接
        try {
            input.close();
            output.close();
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void updateGame() {
        // 逻辑更新（如玩家位置、AI 移动等）
    }

    private static void sendMessage(String message) {
        try {
            output.writeUTF(message);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 监听服务器消息的线程
    private static class ServerListener implements Runnable {
        @Override
        public void run() {
            try {
                while (isRunning) {
                    // 从服务器接收消息
                    String message = input.readUTF();
                    if (message != null) {
                        System.out.println("Game State: " + message);
                        processGameState(message);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private static void processGameState(String message) {
            // 清空旧数据，防止重复添加
            avatarPlayers.clear();
            dots.clear();
            aiPlayers.clear();

            String[] gameState = message.split(";");
            for (String state : gameState) {
                if (state.startsWith("player:")) {
                    String[] playerData = state.substring(7).split(",");
                    int playerX = Integer.parseInt(playerData[0]);
                    int playerY = Integer.parseInt(playerData[1]);
                    int playerRadius = Integer.parseInt(playerData[2]);

                    // 创建 AvatarPlayer 对象并添加到集合
                    AvatarPlayer avatar = new AvatarPlayer(playerX, playerY, playerRadius, 4);  // 速度假设为4
                    avatarPlayers.add(avatar);

                } else if (state.startsWith("dot:")) {
                    String[] dotData = state.substring(4).split(",");
                    int dotX = Integer.parseInt(dotData[0]);
                    int dotY = Integer.parseInt(dotData[1]);

                    // 创建 Point 对象并添加到 dots 集合
                    dots.add(new Point(dotX, dotY));

                } else if (state.startsWith("ai:")) {
                    String[] aiData = state.substring(3).split(",");
                    int aiX = Integer.parseInt(aiData[0]);
                    int aiY = Integer.parseInt(aiData[1]);
                    int aiRadius = Integer.parseInt(aiData[2]);

                    // 创建 AIPlayer 对象并添加到集合
                    AIPlayer aiPlayer = new AIPlayer(aiX, aiY, aiRadius);
                    aiPlayers.add(aiPlayer);
                }
            }

            // 处理完数据后，你可以在此处更新界面或做其他处理

        }

    }

    // 玩家类
    static class AvatarPlayer {
        int x, y, radius, speed;

        public AvatarPlayer(int x, int y, int radius, int speed) {
            this.x = x;
            this.y = y;
            this.radius = radius;
            this.speed = speed;
        }
    }

    // AI 玩家类
    static class AIPlayer {
        int x, y, radius;

        public AIPlayer(int x, int y, int radius) {
            this.x = x;
            this.y = y;
            this.radius = radius;
        }
    }
}
