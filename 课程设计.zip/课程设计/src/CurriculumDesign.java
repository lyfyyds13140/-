import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;

public class CurriculumDesign {
    public  static void showScores() {
        DatabaseHelper.fetchScores();
    }

    public  static void saveScoreToDatabase() {
        String playerName = "刘亚锋";  // 玩家名字，可以根据实际情况进行修改
        //int Score =score;// 获取当前分数
        //DatabaseHelper.insertScore(playerName, Score);
    }
    public static void main(String[] args) {
        // 创建窗体
        JFrame frame = new JFrame("点击查询排名");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1600, 1000);

        // 创建按钮
        JButton runButton = new JButton("单机模式");
        JButton runButton2 = new JButton("点击查询排名");
        runButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 点击按钮时执行另一个程序

                runAnotherJavaProgram();
            }
        });
        runButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // 点击按钮时执行另一个程序
                new TopScoresFrame().setVisible(true);}});
        // 设置布局
        JPanel panel = new JPanel();
        panel.add(runButton);
        panel.add(runButton2);
        // 添加到窗体
        frame.add(panel);
        frame.setVisible(true);
    }

    // 使用 ProcessBuilder 启动另一个 Java 程序
    private static void runAnotherJavaProgram() {
        try {

            // 指定.exe程序的路径
            String command = "C:\\Users\\33549\\Desktop\\课程设计\\程序\\大衍筮.exe";

            // 创建 ProcessBuilder 实例
            ProcessBuilder processBuilder = new ProcessBuilder(command);

            // 启动外部程序
            Process process = processBuilder.start();

            // 等待程序执行完毕
          //  process.waitFor();
            System.out.println("程序已执行完毕");


        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "启动另一个程序失败：" + e.getMessage());
        }
    }
}
