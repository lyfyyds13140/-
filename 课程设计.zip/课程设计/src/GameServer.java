import java.io.*;
import java.net.*;
import java.util.*;
import java.awt.Point;

public class GameServer {
    private static final int PORT = 12345;  // 服务器监听端口
    private static final List<ClientHandler> clients = new ArrayList<>();  // 存储所有客户端
    private static final ArrayList<AvatarPlayer> avatarPlayer = new ArrayList<>();
    private static final ArrayList<AIPlayer> aiPlayers = new ArrayList<>();
    private static final ArrayList<Point> dots = new ArrayList<>();
    private static final ArrayList<Point> playdots = new ArrayList<>();

    // 处理碰撞检测
    public static void checkCollision() {
        ArrayList<Point> eatendots1 = new ArrayList<>();
        ArrayList<Point> eatendots2 = new ArrayList<>();
        ArrayList<AIPlayer> eatenAIPlayers = new ArrayList<>();
        ArrayList<AvatarPlayer> eatenavatarPlayer = new ArrayList<>();

        // 玩家之间的碰撞检测
        for (int i = 0; i < avatarPlayer.size() - 1; i++) {
            AvatarPlayer avatarplayer1 = avatarPlayer.get(i); // 获取第 i 个玩家
            for (int j = i + 1; j < avatarPlayer.size(); j++) {
                AvatarPlayer avatarplayer2 = avatarPlayer.get(j); // 获取第 j 个玩家
                // 计算两个玩家之间的距离，判断是否发生碰撞
                if (Math.hypot(avatarplayer1.circleX - avatarplayer2.circleX, avatarplayer1.circleY - avatarplayer2.circleY) < (avatarplayer1.RADIUS + avatarplayer2.RADIUS) / 2) {
                    eatenavatarPlayer.add(avatarplayer2);  // 被吃掉的玩家
                    avatarplayer1.RADIUS = (int) Math.sqrt(avatarplayer1.RADIUS * avatarplayer1.RADIUS + avatarplayer2.RADIUS * avatarplayer2.RADIUS);  // 玩家变大
                }
            }
            avatarPlayer.removeAll(eatenavatarPlayer);  // 移除被吃掉的玩家
        }

        // 玩家吃掉圆点的检测
        for (AvatarPlayer avatarplayer : avatarPlayer) {
            double x = 20, y = 0, i = 1;
            for (Point dot : dots) {
                if (Math.hypot(avatarplayer.circleX - dot.x, avatarplayer.circleY - dot.y) < avatarplayer.RADIUS) {
                    eatendots1.add(dot);  // 玩家吃掉了小圆点
                    if (avatarplayer.RADIUS <= 250) {
                        y = x;
                        x += 20 / x;  // x递增，每次增加值变小
                        if (x - y >= i) {
                            avatarplayer.RADIUS += 1;  // 玩家变大
                            x = avatarplayer.RADIUS;
                            i = Math.log(avatarplayer.RADIUS - 17);
                            avatarplayer.SPEED = 4 - avatarplayer.RADIUS / 100;
                            if (avatarplayer.RADIUS >= 300) {
                                avatarplayer.SPEED = 1;
                            }
                        }
                    }
                }
            }

            // 玩家与AI的碰撞检测
            for (AIPlayer aiPlayer : aiPlayers) {
                if (Math.hypot(avatarplayer.circleX - aiPlayer.x, avatarplayer.circleY - aiPlayer.y) < (avatarplayer.RADIUS + aiPlayer.radius) / 2) {
                    // 玩家比人机大，吃掉人机并变大
                    if (avatarplayer.RADIUS > aiPlayer.radius) {
                        eatenAIPlayers.add(aiPlayer);  // 被吃掉的人机
                        avatarplayer.RADIUS = (int) Math.sqrt(aiPlayer.radius * aiPlayer.radius + avatarplayer.RADIUS * avatarplayer.RADIUS);  // 玩家变大
                        avatarplayer.SPEED = 4 - avatarplayer.RADIUS / 100;
                        if (avatarplayer.RADIUS >= 300) {
                            avatarplayer.SPEED = 1;
                        }
                    }
                }
            }

            // 玩家与playdots的碰撞检测
            for (Point playdot : playdots) {
                if (Math.hypot(avatarplayer.circleX - playdot.x, avatarplayer.circleY - playdot.y) < avatarplayer.RADIUS) {
                    eatendots2.add(playdot);  // 玩家吃掉了playdot
                    avatarplayer.RADIUS += 2;  // 玩家变大
                    avatarplayer.SPEED = 4 - avatarplayer.RADIUS / 100;
                    if (avatarplayer.RADIUS >= 300) {
                        avatarplayer.SPEED = 1;
                    }
                }
            }
        }

        // 移除吃掉的AI和圆点
        aiPlayers.removeAll(eatenAIPlayers);
        playdots.removeAll(eatendots2);
        dots.removeAll(eatendots1);

        // 广播更新后的数据给所有客户端
        broadcastGameState();
    }

    // 广播游戏状态给所有客户端
    private static void broadcastGameState() {
        // 将更新后的游戏状态广播给所有客户端
        StringBuilder message = new StringBuilder();
        for (AvatarPlayer avatarplayer : avatarPlayer) {
            message.append("player:").append(avatarplayer.circleX).append(",").append(avatarplayer.circleY).append(",").append(avatarplayer.RADIUS).append(";");
        }
        for (Point dot : dots) {
            message.append("dot:").append(dot.x).append(",").append(dot.y).append(";");
        }
        for (AIPlayer aiPlayer : aiPlayers) {
            message.append("ai:").append(aiPlayer.x).append(",").append(aiPlayer.y).append(",").append(aiPlayer.radius).append(";");
        }

        // 广播信息给所有客户端
        for (ClientHandler client : clients) {
            client.sendMessage(message.toString());
        }
    }

    // 客户端处理线程（示例）
    private static class ClientHandler implements Runnable {
        private final Socket socket;
        private final DataInputStream input;
        private final DataOutputStream output;
        private AvatarPlayer player;

        // 构造方法初始化客户端连接
        public ClientHandler(Socket socket) throws IOException {
            this.socket = socket;
            this.input = new DataInputStream(socket.getInputStream());  // 获取输入流
            this.output = new DataOutputStream(socket.getOutputStream());  // 获取输出流
            this.player = new AvatarPlayer(100, 100, 20, 4);  // 初始化玩家信息，位置在(100, 100)，半径为20，速度为4
        }

        @Override
        public void run() {
            try {
                // 接收客户端发送的玩家数据
                while (true) {
                    String message = input.readUTF();  // 读取客户端发送的消息
                    if (message.equals("exit")) break;  // 客户端退出时，跳出循环

                    // 解析客户端数据并更新玩家位置
                    String[] data = message.split(",");
                    int newX = Integer.parseInt(data[0]);  // 获取新的X坐标
                    int newY = Integer.parseInt(data[1]);  // 获取新的Y坐标

                    // 更新玩家的位置
                    player.circleX = newX;
                    player.circleY = newY;

                    // 广播更新后的玩家位置
                    GameServer.broadcast(player.circleX + "," + player.circleY);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    socket.close();  // 关闭连接
                    GameServer.removeClient(this);  // 从客户端列表中移除该客户端
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        // 向客户端发送消息
        public void sendMessage(String message) {
            try {
                output.writeUTF(message);  // 发送消息到客户端
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // 启动服务器
    public static void main(String[] args) {
// 在服务端初始化时，生成5000个随机圆点
        Random random = new Random();
        for (int i = 0; i < 5000; i++) {
            int x = random.nextInt(8000);  // 随机生成 X 坐标
            int y = random.nextInt(8000);  // 随机生成 Y 坐标
            dots.add(new Point(x, y));     // 将圆点添加到 dots 集合中
        }

        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server started on port " + PORT);

            // 等待客户端连接
            while (true) {
                Socket socket = serverSocket.accept();  // 接受一个客户端的连接
                System.out.println("New client connected: " + socket.getInetAddress());

                // 创建新的客户端处理线程
                ClientHandler clientHandler = new ClientHandler(socket);
                clients.add(clientHandler);  // 添加客户端到列表
                new Thread(clientHandler).start();  // 启动新线程来处理该客户端
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // 广播所有客户端的状态
    public static void broadcast(String message) {
        // 遍历所有客户端并发送消息
        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }

    // 移除一个客户端
    public static void removeClient(ClientHandler clientHandler) {
        clients.remove(clientHandler);
    }
}

class AvatarPlayer {
    int circleX, circleY, RADIUS, SPEED;

    public AvatarPlayer(int x, int y, int radius, int speed) {
        this.circleX = x;
        this.circleY = y;
        this.RADIUS = radius;
        this.SPEED = speed;
    }
}

class AIPlayer {
    int x, y, radius;

    public AIPlayer(int x, int y, int radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }
}

