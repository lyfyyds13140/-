package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/updateStudent")
public class UpdateStudentServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        String idStr = request.getParameter("id");
        String studentId = request.getParameter("studentId");
        String name = request.getParameter("name");
        String ageStr = request.getParameter("age");
        String clazz = request.getParameter("clazz");

        if (idStr != null && studentId != null && name != null && ageStr != null && clazz != null) {
            int id = Integer.parseInt(idStr);
            int age = Integer.parseInt(ageStr);

            try (Connection conn = DBUtil.getConnection()) {
                String sql = "UPDATE student SET student_id=?, name=?, age=?, clazz=? WHERE id=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, studentId);
                ps.setString(2, name);
                ps.setInt(3, age);
                ps.setString(4, clazz);
                ps.setInt(5, id);

                int rows = ps.executeUpdate();
                System.out.println("更新成功行数：" + rows);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        response.sendRedirect("listStudent");
    }
}
