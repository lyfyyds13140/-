package servlet;

import util.DBUtil;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import java.sql.*;

@WebServlet("/bindStudent")
public class BindStudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String studentNumber = request.getParameter("studentNumber");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null || studentNumber == null || studentNumber.trim().isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            // 检查是否存在该学号
            String checkSql = "SELECT id, user_id FROM student WHERE student_number = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, studentNumber);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                Integer existingUserId = rs.getInt("user_id");
                if (existingUserId != 0) {
                    response.getWriter().println("<p style='color:red;'>该学号已绑定其他账户！</p>");
                    return;
                }

                int studentId = rs.getInt("id");

                // 绑定：更新 student.user_id
                String updateSql = "UPDATE student SET user_id = ? WHERE id = ?";
                PreparedStatement updateStmt = conn.prepareStatement(updateSql);
                updateStmt.setInt(1, userId);
                updateStmt.setInt(2, studentId);
                updateStmt.executeUpdate();

                response.sendRedirect("bindStudent.jsp");
            } else {
                response.getWriter().println("<p style='color:red;'>学号不存在！</p>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<p style='color:red;'>绑定失败：" + e.getMessage() + "</p>");
        }
    }
}
