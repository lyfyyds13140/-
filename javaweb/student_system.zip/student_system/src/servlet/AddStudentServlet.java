package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class AddStudentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");

        String studentId = request.getParameter("student_id");
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String clazz = request.getParameter("clazz");

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "INSERT INTO student (student_id, name, age, clazz) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(studentId));
            ps.setString(2, name);
            ps.setInt(3, Integer.parseInt(age));
            ps.setString(4, clazz);
            ps.executeUpdate();

            response.sendRedirect("listStudent"); // 成功后跳转
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("添加失败：" + e.getMessage());
        }
    }
}
