package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/addCourseSelection")
public class AddCourseSelectionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        int studentUserId = Integer.parseInt(request.getParameter("studentId"));  // 这里是 student.user_id
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        try (Connection conn = DBUtil.getConnection()) {
            // 改为从 courses 和 teacher 表中查询
            String courseSql = "SELECT c.name AS course_name, t.name AS teacher_name " +
                    "FROM courses c JOIN teacher t ON c.teacher_id = t.id WHERE c.id = ?";
            PreparedStatement coursePs = conn.prepareStatement(courseSql);
            coursePs.setInt(1, courseId);
            ResultSet courseRs = coursePs.executeQuery();

            if (!courseRs.next()) {
                response.getWriter().println("课程不存在");
                return;
            }

            String courseName = courseRs.getString("course_name");
            String teacherName = courseRs.getString("teacher_name");

            // 检查是否重复选课
            String checkSql = "SELECT COUNT(*) FROM student_courses WHERE student_id=? AND course_id=?";
            PreparedStatement checkPs = conn.prepareStatement(checkSql);
            checkPs.setInt(1, studentUserId);
            checkPs.setInt(2, courseId);
            ResultSet checkRs = checkPs.executeQuery();
            if (checkRs.next() && checkRs.getInt(1) > 0) {
                response.getWriter().println("该学生已选过此课程");
                return;
            }

            // 插入 student_courses
            String insertSql = "INSERT INTO student_courses (student_id, course_id, course_name, teacher_name) VALUES (?, ?, ?, ?)";
            PreparedStatement insertPs = conn.prepareStatement(insertSql);
            insertPs.setInt(1, studentUserId);
            insertPs.setInt(2, courseId);
            insertPs.setString(3, courseName);
            insertPs.setString(4, teacherName);
            insertPs.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("添加选课失败：" + e.getMessage());
            return;
        }


        // 添加成功后跳转回课程学生列表页（假设你有这个页面）
        response.sendRedirect("gradeStudents.jsp?courseId=" + courseId);
    }
}
