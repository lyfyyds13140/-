package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/listStudent")
public class ListStudentServlet extends HttpServlet {

    private static final int PAGE_SIZE = 10;

    // 内部静态类表示一个学生
    public static class Student {
        private int id;
        private String studentId; // 新添加字段
        private String name;
        private int age;
        private String clazz;

        public Student(int id, String studentId, String name, int age, String clazz) {
            this.id = id;
            this.studentId = studentId;
            this.name = name;
            this.age = age;
            this.clazz = clazz;
        }

        public int getId() { return id; }
        public String getStudentId() { return studentId; }
        public String getName() { return name; }
        public int getAge() { return age; }
        public String getClazz() { return clazz; }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String pageStr = request.getParameter("page");
        int page = 1;
        if (pageStr != null) {
            try {
                page = Integer.parseInt(pageStr);
                if (page < 1) page = 1;
            } catch (NumberFormatException ignored) {}
        }

        String keyword = request.getParameter("keyword");
        if (keyword == null) keyword = "";
        keyword = "%" + keyword.trim() + "%";

        List<Student> students = new ArrayList<>();
        int totalCount = 0;
        int totalPages = 0;

        try (Connection conn = DBUtil.getConnection()) {

            // 查询总条数
            String countSql = "SELECT COUNT(*) FROM student WHERE name LIKE ? OR clazz LIKE ? OR student_id LIKE ?";
            PreparedStatement countPs = conn.prepareStatement(countSql);
            countPs.setString(1, keyword);
            countPs.setString(2, keyword);
            countPs.setString(3, keyword);
            ResultSet countRs = countPs.executeQuery();
            if (countRs.next()) {
                totalCount = countRs.getInt(1);
            }

            totalPages = (int) Math.ceil((double) totalCount / PAGE_SIZE);
            if (page > totalPages && totalPages != 0) page = totalPages;

            // 查询分页数据
            String sql = "SELECT id, student_id, name, age, clazz FROM student " +
                    "WHERE name LIKE ? OR clazz LIKE ? OR student_id LIKE ? " +
                    "ORDER BY id LIMIT ?, ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, keyword);
            ps.setString(2, keyword);
            ps.setString(3, keyword);
            ps.setInt(4, (page - 1) * PAGE_SIZE);
            ps.setInt(5, PAGE_SIZE);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                students.add(new Student(
                        rs.getInt("id"),
                        rs.getString("student_id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("clazz")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("students", students);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);
        request.setAttribute("keyword", keyword.replace("%", ""));

        request.getRequestDispatcher("listStudent.jsp").forward(request, response);
    }
}
