package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/addTeacherCourse")
public class AddTeacherCourseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String courseName = request.getParameter("courseName");
        String description = request.getParameter("description");

        try (Connection conn = DBUtil.getConnection()) {
            conn.setAutoCommit(false); // 开启事务

            // 1. 插入 user 表
            String insertUser = "INSERT INTO user (username, password, role) VALUES (?, ?, ?)";
            PreparedStatement userStmt = conn.prepareStatement(insertUser, Statement.RETURN_GENERATED_KEYS);
            userStmt.setString(1, email); // 使用邮箱作为用户名
            userStmt.setString(2, "123456"); // 默认密码，建议后续加密
            userStmt.setString(3, "teacher");
            userStmt.executeUpdate();

            ResultSet userRs = userStmt.getGeneratedKeys();
            if (!userRs.next()) throw new SQLException("无法获取用户ID");
            int userId = userRs.getInt(1); // 用作 teacher.id

            // 2. 插入 teacher 表，使用 user.id 作为 id
            String insertTeacher = "INSERT INTO teacher (id, name, email, phone) VALUES (?, ?, ?, ?)";
            PreparedStatement teacherStmt = conn.prepareStatement(insertTeacher);
            teacherStmt.setInt(1, userId);
            teacherStmt.setString(2, name);
            teacherStmt.setString(3, email);
            teacherStmt.setString(4, phone);
            teacherStmt.executeUpdate();

            // 3. 插入课程表
            String insertCourse = "INSERT INTO courses (name, teacher_id, description) VALUES (?, ?, ?)";
            PreparedStatement courseStmt = conn.prepareStatement(insertCourse);
            courseStmt.setString(1, courseName);
            courseStmt.setInt(2, userId); // 同样是 userId/teacherId
            courseStmt.setString(3, description);
            courseStmt.executeUpdate();

            conn.commit();
            response.getWriter().println("<p style='color:green;'>导入成功，教师ID：" + userId + "</p>");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<p style='color:red;'>导入失败：" + e.getMessage() + "</p>");
        }
    }
}
