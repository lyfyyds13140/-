package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/updateSystemSettings")
public class updateSystemSettings extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 设置请求编码，防止中文乱码
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession(false);
        if (session == null || !"admin".equalsIgnoreCase((String)session.getAttribute("role"))) {
            // 没有登录或不是管理员，重定向登录页
            response.sendRedirect("login.jsp");
            return;
        }

        String systemName = request.getParameter("systemName");
        String version = request.getParameter("version");

        if (systemName == null || systemName.trim().isEmpty() || version == null || version.trim().isEmpty()) {
            request.setAttribute("error", "系统名称和版本号不能为空");
            request.getRequestDispatcher("systemSettings.jsp").forward(request, response);
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            // 假设系统设置表只有一条数据，更新即可
            String sql = "UPDATE system_settings SET system_name = ?, version = ? WHERE id = 1";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, systemName);
            ps.setString(2, version);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                // 记录更新日志（可选）
                String logSql = "INSERT INTO system_logs(username, action) VALUES (?, ?)";
                PreparedStatement logPs = conn.prepareStatement(logSql);
                logPs.setString(1, (String)session.getAttribute("username"));
                logPs.setString(2, "更新系统设置为: 系统名称=" + systemName + ", 版本=" + version);
                logPs.executeUpdate();

                request.setAttribute("message", "系统设置更新成功！");
            } else {
                request.setAttribute("error", "系统设置更新失败，数据不存在。");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "数据库操作异常：" + e.getMessage());
        }

        // 更新后返回设置页面并显示消息
        request.getRequestDispatcher("systemSettings.jsp").forward(request, response);
    }
}
