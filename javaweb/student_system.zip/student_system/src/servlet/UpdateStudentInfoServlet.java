package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.util.Base64;
import java.io.FileOutputStream;

@WebServlet("/updateStudentInfo")
@MultipartConfig
public class UpdateStudentInfoServlet extends HttpServlet {
    private static final String UPLOAD_DIR = "upload";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // 基本字段
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");
        String birthday = request.getParameter("birthday");
        String address = request.getParameter("address");
        String base64Photo = request.getParameter("cameraPhoto");

        String fileName = null;

        // 方法一：摄像头 base64 照片
        if (base64Photo != null && base64Photo.startsWith("data:image")) {
            String base64 = base64Photo.split(",")[1];
            byte[] data = Base64.getDecoder().decode(base64);

            fileName = "user_" + userId + ".png";
            String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
            File uploadDir = new File(uploadPath);
            if (!uploadDir.exists()) uploadDir.mkdir();

            try (FileOutputStream fos = new FileOutputStream(new File(uploadDir, fileName))) {
                fos.write(data);
            }
        }

        // 方法二：普通文件上传
        if ((fileName == null || fileName.isEmpty()) && request.getPart("photo") != null) {
            Part photoPart = request.getPart("photo");
            if (photoPart.getSize() > 0) {
                String submittedFileName = photoPart.getSubmittedFileName();
                String ext = submittedFileName.substring(submittedFileName.lastIndexOf('.'));
                fileName = "user_" + userId + ext;

                String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
                File uploadDir = new File(uploadPath);
                if (!uploadDir.exists()) uploadDir.mkdir();

                File file = new File(uploadDir, fileName);
                try (InputStream is = photoPart.getInputStream()) {
                    Files.copy(is, file.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }

        try (Connection conn = DBUtil.getConnection()) {
            String checkSql = "SELECT * FROM student WHERE user_id=?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setInt(1, userId);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                StringBuilder updateSql = new StringBuilder("UPDATE student SET name=?, email=?, phone=?, gender=?, birthday=?, address=?");
                if (fileName != null) updateSql.append(", photo_path=?");
                updateSql.append(" WHERE user_id=?");

                PreparedStatement ps = conn.prepareStatement(updateSql.toString());
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, phone);
                ps.setString(4, gender);
                ps.setString(5, birthday);
                ps.setString(6, address);
                if (fileName != null) {
                    ps.setString(7, fileName);
                    ps.setInt(8, userId);
                } else {
                    ps.setInt(7, userId);
                }
                ps.executeUpdate();
            } else {
                String insertSql = "INSERT INTO student (user_id, name, email, phone, gender, birthday, address, photo_path) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
                PreparedStatement ps = conn.prepareStatement(insertSql);
                ps.setInt(1, userId);
                ps.setString(2, name);
                ps.setString(3, email);
                ps.setString(4, phone);
                ps.setString(5, gender);
                ps.setString(6, birthday);
                ps.setString(7, address);
                ps.setString(8, fileName != null ? fileName : "default.png");
                ps.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("studentCenter.jsp?success=1");
    }
}

