package servlet;

import util.DBUtil;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String inputCode = request.getParameter("verify");
        String sessionCode = (String) request.getSession().getAttribute("verifyCode");

        // 验证码校验
        if (sessionCode == null || !sessionCode.equalsIgnoreCase(inputCode)) {
            response.sendRedirect("login.jsp?error=2"); // 验证码错误
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            String sql = "SELECT id, role FROM user WHERE username = ? AND password = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, username);
                stmt.setString(2, password);

                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        // 从数据库读取角色
                        String userRole = rs.getString("role");

                        // 登录成功，保存用户名和角色到session
                        HttpSession session = request.getSession();
                        session.setAttribute("username", username);
                        session.setAttribute("role", userRole);
                        session.setAttribute("userId", rs.getInt("id"));
                        // 添加用户Cookie
                        Cookie userCookie = new Cookie("user", username);
                        userCookie.setMaxAge(60 * 60 * 24 * 7); // 7天
                        response.addCookie(userCookie);
                        String logSql = "INSERT INTO system_logs(username, action) VALUES (?, ?)";
                        PreparedStatement logPs = conn.prepareStatement(logSql);
                        logPs.setString(1, username);
                        logPs.setString(2, "登录系统");
                        logPs.executeUpdate();
                        if ("student".equalsIgnoreCase(userRole)) {
                            response.sendRedirect("student.jsp");
                        } else if ("teacher".equalsIgnoreCase(userRole)) {
                            response.sendRedirect("teacherDashboard.jsp");
                        } else if ("admin".equalsIgnoreCase(userRole)) {
                            response.sendRedirect("adminPanel.jsp");
                        }


                    } else {
                        // 登录失败，用户名或密码错误
                        response.sendRedirect("login.jsp?error=1");
                    }
                }
            }
        } catch (Exception e) {
            response.getWriter().println("Database error: " + e.getMessage());
        }
    }
}
