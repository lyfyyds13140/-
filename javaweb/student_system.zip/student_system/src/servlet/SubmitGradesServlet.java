package servlet;

import util.DBUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/submitGrades")
public class SubmitGradesServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        int courseId = Integer.parseInt(request.getParameter("courseId"));

        try (Connection conn = DBUtil.getConnection()) {
            Enumeration<String> paramNames = request.getParameterNames();
            while (paramNames.hasMoreElements()) {
                String paramName = paramNames.nextElement();
                if (paramName.startsWith("grade_")) {
                    int scId = Integer.parseInt(paramName.substring(6));
                    String grade = request.getParameter(paramName);

                    String sql = "UPDATE student_courses SET grade=? WHERE student_id=? AND course_id=?";
                    PreparedStatement ps = conn.prepareStatement(sql);
                    ps.setString(1, grade);
                    ps.setInt(2, scId);
                    ps.setInt(3,courseId);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            response.getWriter().println("<p style='color:red;'>提交失败：" + e.getMessage() + "</p>");
            return;
        }

        response.sendRedirect("manageCourses.jsp");
    }
}
