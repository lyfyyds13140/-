package servlet;

import util.DBUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/updateRole")
public class UpdateRoleServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String idStr = request.getParameter("id");
        String newRole = request.getParameter("newRole");

        if (idStr == null || newRole == null) {
            response.sendRedirect("manageRoles.jsp");
            return;
        }

        try (Connection conn = DBUtil.getConnection()) {
            // 更新用户角色
            String updateSql = "UPDATE user SET role = ? WHERE id = ?";
            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, newRole);
                ps.setInt(2, Integer.parseInt(idStr));
                ps.executeUpdate();
            }

            // 查询被修改用户的用户名，用来判断是否同步当前登录用户 session
            String queryUserSql = "SELECT username FROM user WHERE id = ?";
            String updatedUsername = null;
            try (PreparedStatement ps = conn.prepareStatement(queryUserSql)) {
                ps.setInt(1, Integer.parseInt(idStr));
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        updatedUsername = rs.getString("username");
                    }
                }
            }

            // 同步修改当前登录用户session中角色（如果修改的是自己）
            HttpSession session = request.getSession(false);
            if (session != null && updatedUsername != null) {
                String loginUsername = (String) session.getAttribute("username");
                if (loginUsername != null && loginUsername.equals(updatedUsername)) {
                    session.setAttribute("role", newRole);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            // 可以添加错误处理逻辑，比如跳转错误页面或显示错误消息
        }

        // 修改完重定向回管理页面
        response.sendRedirect("manageRoles.jsp");
    }
}
