package servlet;

import util.DBUtil;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.*;
import java.util.*;

@WebServlet("/listTeacher")
public class ListTeacherServlet extends HttpServlet {
    private static final int PAGE_SIZE = 5;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String keyword = request.getParameter("keyword");
        if (keyword == null) keyword = "";

        int page = 1;
        try {
            page = Integer.parseInt(request.getParameter("page"));
        } catch (Exception ignored) {}

        List<Map<String, Object>> teachers = new ArrayList<>();
        int totalCount = 0;

        try (Connection conn = DBUtil.getConnection()) {
            // 获取总数
            String countSql = "SELECT COUNT(*) FROM teacher WHERE name LIKE ?";
            try (PreparedStatement countPs = conn.prepareStatement(countSql)) {
                countPs.setString(1, "%" + keyword + "%");
                ResultSet rs = countPs.executeQuery();
                if (rs.next()) totalCount = rs.getInt(1);
            }

            // 获取分页数据
            String sql = "SELECT * FROM teacher WHERE name LIKE ? LIMIT ?, ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, "%" + keyword + "%");
                ps.setInt(2, (page - 1) * PAGE_SIZE);
                ps.setInt(3, PAGE_SIZE);
                ResultSet rs = ps.executeQuery();

                while (rs.next()) {
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", rs.getInt("id"));
                    map.put("name", rs.getString("name"));
                    map.put("email", rs.getString("email"));
                    map.put("phone", rs.getString("phone"));
                    teachers.add(map);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        int totalPages = (int) Math.ceil((double) totalCount / PAGE_SIZE);
        request.setAttribute("teachers", teachers);
        request.setAttribute("keyword", keyword);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);

        request.getRequestDispatcher("teacherList.jsp").forward(request, response);
    }
}
