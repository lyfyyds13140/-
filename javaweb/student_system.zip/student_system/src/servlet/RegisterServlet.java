package servlet;

import dao.UserDao;
import model.User;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class RegisterServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        User user = new User(username, password, "student");
        UserDao dao = new UserDao();
        boolean success = dao.register(user);

        if (success) {
            response.sendRedirect("login.jsp");
        } else {
            response.getWriter().println("注册失败，用户名可能已存在。<a href='register.jsp'>返回</a>");
        }
    }
}
