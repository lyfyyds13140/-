package filter;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;
import java.io.IOException;
public class RoleFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String path = req.getRequestURI();
        String contextPath = req.getContextPath();

        // 放行登录页、静态资源等，不拦截
        if  (path.equals(contextPath + "/login.jsp") ||
                path.equals(contextPath + "/register.jsp") ||
                path.equals(contextPath + "/login") || // servlet
                path.equals(contextPath + "/register") || // servlet
                path.equals(contextPath + "/verify.jsp") ||
                path.endsWith(".css") ||
                path.endsWith(".js") ||
                path.endsWith(".png") ||
                path.endsWith(".jpg") ||
                path.endsWith(".gif") ||
                path.contains("/static/") || path.contains("/assets/")
        )
        {
            chain.doFilter(request, response);
            return;
        }

        // 判断是否登录
        if (session == null || session.getAttribute("username") == null) {
            resp.sendRedirect(contextPath + "/login.jsp");
            return;
        }

        // 获取角色
        String role = (String) session.getAttribute("role");
        if (role == null) {
            resp.sendRedirect(contextPath + "/login.jsp");
            return;
        }

        // 角色权限判断举例：
        // 只有admin角色可以访问/admin路径
        if (path.startsWith(contextPath + "/admin")) {
            if (!"admin".equals(role)) {
                resp.sendRedirect(contextPath + "/noPermission.jsp");
                return;
            }
        }

        // 只有teacher角色可以访问/teacher路径
        if (path.startsWith(contextPath + "/teacher")) {
            if (!"teacher".equals(role) && !"admin".equals(role)) {
                resp.sendRedirect(contextPath + "/noPermission.jsp");
                return;
            }
        }

        // 普通用户限制例子，也可以写更多判断

        // 放行
        chain.doFilter(request, response);
    }
}
